/////////////////////////////////////////////////////////////////////////////////////
// TestExecutive.cpp - demonstrate requirements of the project				   //
// Author: Beier Chen, bchen22@syr.edu												 	   //
// Application: Project 2 - CSE687 - Object Oriented Design, Spring 2018   //   
/////////////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* executes a sequence of tests to demonstrate core Repository functionality.
*
* Required Files:
* ---------------
* TestExecutive.h
*
* Build Process:
* --------------
* devenv Project2-Repository.sln /rebuild debug
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 Mar 2018
* - first release
*
*/

#include "TestExecutive.h"

using namespace NoSqlDb;
using namespace RepositoryCore;
using namespace Utilities;

bool TestRepo::testForReq3()
{
	Utilities::title("Demonstrating Requirement #3 -"
		" include C++ packages: TestExecutive, CheckIn, CheckOut, Version and Browse");
	cout << "\n  - check project code to verify";
	return true;
}

bool TestRepo::testForCheckIn1()
{
	Utilities::Title("Demonstrating Requirement #3 - Check-in and Requirement #4");
	Utilities::putline();
	
	DbElement<PayLoad> elem;
	PayLoad pl;
	string filePath;
	repo_.checkIn().logIn("B. Chen");
	cout << "\n - Currently loging as: " << repo_.checkIn().logInName() << endl;
	
	Utilities::title("Domonstrating check-in by accepting a files and append a version number to the end of file name.");
	filePath = "../Files-To-Check-In-Storage/DateTime/DateTime.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().push_back("DateTime");
	elem.descrip("DateTime header file");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // 1st check in
	showDb(repo_.db());
	elem.payLoad().showDb(repo_.db());

	cout <<"\n\n";
	Utilities::title("Domonstrating checking in a file with open check-in state");
	cout << "\n - Checking-in file: " << filePath;
	repo_.checkIn().checkIn(filePath, elem); // 2nd check in
	showDb(repo_.db());
	elem.payLoad().showDb(repo_.db());

	cout << "\n\n";
	Utilities::title("Domonstrating checking in a file with closed check-in state");
	repo_.checkIn().close(filePath); 
	showDb(repo_.db());
	elem.payLoad().showDb(repo_.db());

	cout << "\n\n - Checking-in file: " << filePath;
	repo_.checkIn().checkIn(filePath, elem); // 3rd check in
	showDb(repo_.db());
	elem.payLoad().showDb(repo_.db());
	return true;
}

void TestRepo::makeTestRepo1()
{
	DbElement<PayLoad> elem;
	PayLoad pl;
	string filePath;
	Utilities::title("Checking several files for test");

	filePath = "../Files-To-Check-In-Storage/DateTime/DateTime.cpp";
	cout << "\n - Checking-in file: " << filePath;
	elem.descrip("DateTime main file");
	elem.children().clear();
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in 

	filePath = "../Files-To-Check-In-Storage/DbCore/DbCore.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().clear();
	elem.children().clear();
	pl.categories().push_back("DbCore");
	elem.descrip("DbCore header file");
	elem.addChildKey("DateTime.h");
	elem.addChildKey("Query.h");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in 

	filePath = "../Files-To-Check-In-Storage/Query/Query.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().clear();
	elem.children().clear();
	pl.categories().push_back("Query");
	elem.descrip("Query header file");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in 

	filePath = "../Files-To-Check-In-Storage/XmlDocument/XmlElement.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().clear();
	elem.children().clear();
	pl.categories().push_back("XmlElement");
	elem.descrip("XmlElement header file");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in 
}

void TestRepo::makeTestRepo2()
{
	DbElement<PayLoad> elem;
	PayLoad pl;
	string filePath;

	filePath = "../Files-To-Check-In-Storage/XmlDocument/XmlDocument.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().clear();
	elem.children().clear();
	pl.categories().push_back("XmlDocument");
	elem.addChildKey("XmlElement.h");
	elem.descrip("XmlDocument header file");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in 

	// check in 
	filePath = "../Files-To-Check-In-Storage/Persist/Persist.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().clear();
	elem.children().clear();
	pl.categories().push_back("Persist");
	elem.addChildKey("DbCore.h");
	elem.addChildKey("DateTime.h");
	elem.addChildKey("Query.h");
	elem.addChildKey("XmlDocument.h");
	elem.descrip("Persist header file");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in
							
	filePath = "../Files-To-Check-In-Storage/Executive/Executive.h";
	cout << "\n - Checking-in file: " << filePath;
	pl.categories().clear();
	elem.children().clear();
	pl.categories().push_back("Executive");
	elem.addChildKey("DbCore.h");
	elem.addChildKey("DateTime.h");
	elem.addChildKey("Query.h");
	elem.addChildKey("Persist.h");
	elem.addChildKey("XmlDocument.h");
	elem.descrip("Executive header file");
	elem.payLoad(pl);
	repo_.checkIn().checkIn(filePath, elem); // check in 

	showDb(repo_.db());
	elem.payLoad().showDb(repo_.db());
}

bool TestRepo::testForCheckIn2()
{
	DbElement<PayLoad> elem;
	PayLoad pl;
	string filePath;

	makeTestRepo1();
	makeTestRepo2();

	cout << "\n\n";
	Utilities::title("Domonstrating trying to close a file with dependent files are open check-in state ");
	filePath = "../Files-To-Check-In-Storage/Persist/Persist.h";
	repo_.checkIn().close(filePath);

	filePath = "../Files-To-Check-In-Storage/DateTime/DateTime.h";
	repo_.checkIn().close(filePath);

	filePath = "../Files-To-Check-In-Storage/Persist/Persist.h";
	repo_.checkIn().close(filePath);

	Utilities::title("Domonstrating trying to close a file with all the state dependent files are closed check-in ");
	filePath = "../Files-To-Check-In-Storage/XmlDocument/XmlElement.h";
	repo_.checkIn().close(filePath);
	filePath = "../Files-To-Check-In-Storage/XmlDocument/XmlDocument.h";
	repo_.checkIn().close(filePath);
	filePath = "../Files-To-Check-In-Storage/Query/Query.h";
	repo_.checkIn().close(filePath);
	filePath = "../Files-To-Check-In-Storage/DbCore/DbCore.h";
	repo_.checkIn().close(filePath);

	Utilities::title("After all the dependent files are in closed check-in, close Persist.h again");
	filePath = "../Files-To-Check-In-Storage/Persist/Persist.h";
	repo_.checkIn().close(filePath);

	return true;
}

bool TestRepo::testForCheckOut() 
{
	Utilities::Title("Domonstrating Requirement #3 - Check-out");
	Utilities::title("retrieves package files, removing version information from their filenames");

	showDb(repo_.db());
	repo_.checkOut().checkout("Persist.h");
	return true;
}

bool TestRepo::testForBrowse() 
{
	Utilities::Title("Domonstrating Requirement #3 - Browse and Requirement #4");
	Utilities::title("support browsing files by displaying descriptions. ");

	Browse<PayLoad> browse(repo_.db());
	browse.browse("Persist.h");

	cout << "\n";
	browse.browse("DateTime.h");

	cout << "\n\n";
	Utilities::title("Display full text of file, identified by one of the keys returned from the initial browse query.");

	browse.browse("Executive.h").showContent();
	return true;
}

int main()
{
	DbCore <PayLoad> db;
	Repository<PayLoad> repo(db);

	TestRepo testRepo(repo);
	testRepo.invoke(&TestRepo::testForReq3);
	testRepo.invoke(&TestRepo::testForCheckIn1);
	testRepo.invoke(&TestRepo::testForCheckIn2);
	testRepo.invoke(&TestRepo::testForCheckOut);
	testRepo.invoke(&TestRepo::testForBrowse);

	std::getchar();
	return 0;
}

