#pragma once
/////////////////////////////////////////////////////////////////////////////////////
// TestExecutive.h - Repository function										               //
// Author: Beier Chen, bchen22@syr.edu												 	   //
// Application: Project 2 - CSE687 - Object Oriented Design, Spring 2018   //   
/////////////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* provides means to check-in, version, browse, and check-out source code packages.
*
* Required Files:
* ---------------
* NoSqlDb.h, PayLoad.h, FileManager.h, Version.h, CheckIn.h, CheckOut.h Browse.h
*
* Build Process:
* --------------
* devenv Project2-Repository.sln /rebuild debug
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 Mar 2018
* - first release
*
*/

#include <string>
#include <iostream>
#include <vector>
#include "../NoSqlDb/DbCore/DbCore.h"
#include "../NoSqlDb/PayLoad/PayLoad.h"
#include "../NoSqlDb/Executive/NoSqlDb.h"
#include "../RepositoryCore/RepositoryCore.h"

class TestRepo
{
public:
	using MPtr = bool(TestRepo::*)();

	TestRepo(RepositoryCore::Repository<NoSqlDb::PayLoad>& repo) : repo_(repo) { ; }

	static void identity(std::ostream& out = std::cout);
	bool invoke(MPtr mPtr);
	void makeTestRepo1();
	void makeTestRepo2();
	bool testForReq3(); 
	bool testForCheckIn1(); // Check-in - check in
	bool testForCheckIn2(); // Check-in - close check-in
	bool testForCheckOut(); // Check-out
	bool testForBrowse(); // Browse

private:
	RepositoryCore::Repository<NoSqlDb::PayLoad>& repo_;
};

void TestRepo::identity(std::ostream& out)
{
  out << "\n  \"" << __FILE__ << "\"";
}

bool TestRepo::invoke(TestRepo::MPtr mPtr)
{
  try {
    bool result = ((*this).*mPtr)();
    if (result)
    {
      std::cout << "\npassed <<<<\n";
    }
    else
    {
      std::cout << "\nfailed <<<<\n";
    }
    return result;
  }
  catch (std::exception& ex)
  {
    std::cout << "\n    exception thrown:";
    std::cout << "\n    " << ex.what();
    std::cout << "\nfailed <<<<\n";
    return false;
  }
}